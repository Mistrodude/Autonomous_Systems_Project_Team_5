#!/usr/bin/env python3

import rospy
from ackermann_msgs.msg import AckermannDrive

# Global variables for latest values
latest_speed = 0.0
latest_steering = 0.0

def speed_callback(msg):
    global latest_speed
    latest_speed = msg.speed

def steering_callback(msg):
    global latest_steering
    latest_steering = msg.steering_angle

def publisher_loop():
    pub = rospy.Publisher("/ackermann_cmd", AckermannDrive, queue_size=10)
    rate = rospy.Rate(10)  # 10 Hz

    while not rospy.is_shutdown():
        msg = AckermannDrive()
        msg.speed = latest_speed
        msg.steering_angle = latest_steering
        pub.publish(msg)
        rate.sleep()

def main():
    rospy.init_node("ackermann_mux")

    rospy.Subscriber("/desired_speed", AckermannDrive, speed_callback)
    rospy.Subscriber("/desired_steering", AckermannDrive, steering_callback)

    publisher_loop()

if __name__ == '__main__':
    main()


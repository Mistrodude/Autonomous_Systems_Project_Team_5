#!/usr/bin/env python3

import rospy
import math
import numpy as np
from gazebo_msgs.msg import ModelStates
from ackermann_msgs.msg import AckermannDrive
from tf.transformations import euler_from_quaternion

# --- Parameters ---
k = 1      # Stanley gain
epsilon = 0.1    # To prevent division by zero

# --- Path (Replace with your own waypoints or subscribe) ---
path = np.array([
    [8,11]
])
global ackermann_pub
latest_msg = None
ackermann_pub = None

def get_yaw(q):
    return euler_from_quaternion([q.x, q.y, q.z, q.w])[2]

def closest_point_and_heading(x, y):
    dists = np.linalg.norm(path - np.array([x, y]), axis=1)
    idx = np.argmin(dists)
    closest = path[idx]
    next_pt = path[min(idx + 1, len(path) - 1)]
    heading = math.atan2(next_pt[1] - closest[1], next_pt[0] - closest[0])
    return closest, heading

def stanley_control(x, y, yaw, v):
    closest, path_heading = closest_point_and_heading(x, y)
    theta_e = path_heading - yaw
    theta_e = math.atan2(math.sin(theta_e), math.cos(theta_e))

    dx = closest[0] - x
    dy = closest[1] - y
    cross_track_error = dy * math.cos(path_heading) - dx * math.sin(path_heading)

    delta = theta_e + math.atan2(k * cross_track_error, v + epsilon)
    max_steering_deg = 25
    max_steering_rad = math.radians(max_steering_deg)
    delta = max(-max_steering_rad, min(max_steering_rad, delta))

    return delta

def model_states_callback(msg):
    global latest_msg
    latest_msg = msg

def control_callback(event):
    global latest_msg

    if not latest_msg:
        return

    try:
        index = latest_msg.name.index("ackermann_vehicle")
        pose = latest_msg.pose[index]
        twist = latest_msg.twist[index]

        x = pose.position.x
        y = pose.position.y
        yaw = get_yaw(pose.orientation)
        v = math.sqrt(twist.linear.x**2 + twist.linear.y**2)

        rospy.loginfo(f"[STATE] x={x:.2f} y={y:.2f} yaw={yaw:.2f} v={v:.2f}")

        delta = stanley_control(x, y, yaw, v)

        msg = AckermannDrive()
        msg.steering_angle = delta
        # No speed set
        ackermann_pub.publish(msg)

    except ValueError:
        rospy.logwarn("ackermann_vehicle not found in model_states!")

if __name__ == '__main__':
    rospy.init_node('stanley_controller')

    ackermann_pub = rospy.Publisher("/desired_steering", AckermannDrive, queue_size=10)
    rospy.Subscriber('/gazebo/model_states', ModelStates, model_states_callback)

    rospy.Timer(rospy.Duration(0.1), control_callback)
    rospy.spin()

#!/usr/bin/env python3

import rospy
import sys
import math
from gazebo_msgs.msg import ModelStates
from ackermann_msgs.msg import AckermannDrive

# PID constants and state variables
Kp = 1.0
Ki = 0.1
Kd = 0.05
error = 0
error_prev = 0
int_prev = 0

# Target waypoint (same as in Stanley)
target_point = (8,11)

# Publisher object
ackermann_pub = None
latest_msg = None

def control_output(desired_speed, actual_speed):
    global error, error_prev, int_prev, ackermann_pub

    error = desired_speed - actual_speed
    xi = int_prev + 0.5 * (error + error_prev) * 0.1
    xd = (error - error_prev) / 0.1
    output = Kp * error + Ki * xi + Kd * xd

    int_prev = xi
    error_prev = error

    rospy.loginfo(f"[CONTROL OUTPUT] 🎯 {output:.2f}")

    msg = AckermannDrive()
    msg.speed = output  # Only setting speed
    ackermann_pub.publish(msg)

def model_states_callback(msg):
    global latest_msg
    latest_msg = msg

def process_speed(event):
    global latest_msg

    if not latest_msg:
        return

    try:
        index = latest_msg.name.index("ackermann_vehicle")
        pose = latest_msg.pose[index]
        twist = latest_msg.twist[index]

        x = pose.position.x
        y = pose.position.y
        linear_x = twist.linear.x
        linear_y = twist.linear.y

        actual_speed = math.sqrt(linear_x**2 + linear_y**2)
        rospy.loginfo(f"[ACTUAL SPEED] 🚗 {actual_speed:.2f} m/s")

        # --- Dynamic speed control based on distance to waypoint ---
        target_x, target_y = target_point
        distance = math.sqrt((x - target_x)**2 + (y - target_y)**2)

        if distance > 5.0:
            desired_speed = 2.0
        elif distance > 1.0:
            desired_speed = 0.5
        else:
            desired_speed = 0.0  # Stop at the target

        rospy.loginfo(f"[DISTANCE TO TARGET] 📍 {distance:.2f} m | Desired Speed = {desired_speed:.2f}")
        control_output(desired_speed, actual_speed)

    except ValueError:
        rospy.logwarn("ackermann_vehicle not found in model_states!")

if __name__ == '__main__':
    rospy.init_node('pid_ackermann_controller')

    ackermann_pub = rospy.Publisher("/desired_speed", AckermannDrive, queue_size=10)
    rospy.Subscriber('/gazebo/model_states', ModelStates, model_states_callback)

    rospy.sleep(0.5)
    rospy.Timer(rospy.Duration(0.1), process_speed)
    rospy.spin()

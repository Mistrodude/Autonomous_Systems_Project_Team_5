#!/usr/bin/env python3

import rospy
import math
import numpy as np
from gazebo_msgs.msg import ModelStates
from std_msgs.msg import Float32
from ackermann_msgs.msg import AckermannDrive  # for desired_speed

# --- PID constants ---
Kp = 0.8
Ki = 0.2
Kd = 0.002

# --- Parameters ---
MAX_SPEED = 2.0       # Maximum allowed speed (m/s)

# --- Globals ---
desired_speed = 0.0
latest_msg = None
control_output_pub = None
error = 0.0
error_prev = 0.0
int_prev = 0.0

# --- Path waypoints ---
path = np.array([
    [-0.3,  2],
    [-0.3,  4.5],
    [ 0.35, 5.6],
    [ 0.35, 8],
    [ 0.35, 11.5],
    [-0.3,  13],
    [-0.3,  16],
])
current_index = 0

def desired_speed_callback(msg):
    global desired_speed
    desired_speed = msg.speed

def filtered_states_callback(msg):
    global latest_msg
    latest_msg = msg

def control_output(desired, actual):
    global error, error_prev, int_prev
    error = desired - actual
    xi    = int_prev + 0.5 * (error + error_prev) * 0.1
    xd    = (error - error_prev) / 0.1
    output = Kp*error + Ki*xi + Kd*xd

    # anti-windup
    int_prev = np.clip(xi, -MAX_SPEED, MAX_SPEED)
    error_prev = error

    # publish
    msg = Float32()
    msg.data = output
    control_output_pub.publish(msg)
    rospy.loginfo(f"[PID OUTPUT] Desired: {desired:.2f} m/s | Actual: {actual:.2f} m/s | PID: {output:.2f}")

def process_speed(event):
    global latest_msg, current_index
    if not latest_msg or current_index >= len(path):
        return

    try:
        idx   = latest_msg.name.index("ackermann_vehicle")
        pose  = latest_msg.pose[idx]
        twist = latest_msg.twist[idx]

        x = pose.position.x
        y = pose.position.y
        vx = twist.linear.x
        vy = twist.linear.y
        actual_speed = math.hypot(vx, vy)

        # waypoint logic
        tx, ty = path[current_index]
        dist   = math.hypot(x - tx, y - ty)
        rospy.loginfo(f"[WAYPOINT {current_index}] Target=({tx:.2f},{ty:.2f}) Dist={dist:.2f} m")

        if dist <= 0.5 and current_index < len(path) - 1:
            current_index += 1
            rospy.loginfo(f"[ADVANCING] → waypoint {current_index}")

        control_output(desired_speed, actual_speed)

    except ValueError:
        rospy.logwarn("ackermann_vehicle not found in filtered_model_states!")

if __name__ == '__main__':
    rospy.init_node('pid_speed_controller')

    control_output_pub = rospy.Publisher("/control_output", Float32, queue_size=10)

    # subscribe to filtered data rather than raw Gazebo
    rospy.Subscriber('/filtered_model_states', ModelStates, filtered_states_callback)
    rospy.Subscriber('/desired_speed',        AckermannDrive, desired_speed_callback)

    rospy.sleep(0.5)
    rospy.Timer(rospy.Duration(0.1), process_speed)
    rospy.spin()

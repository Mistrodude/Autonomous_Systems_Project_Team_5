#!/usr/bin/env python3

import rospy
import matplotlib.pyplot as plt
from gazebo_msgs.msg import ModelStates
from std_msgs.msg import String

# Global variables
recording = False
x_positions = []
y_positions = []

latest_msg = None


def model_states_callback(msg):
    global latest_msg
    latest_msg = msg


def command_callback(msg):
    global recording, x_positions, y_positions

    if msg.data.lower() == "start":
        rospy.loginfo("[RECORDER] 🟢 Start recording path!")
        x_positions.clear()
        y_positions.clear()
        recording = True

    elif msg.data.lower() == "stop":
        rospy.loginfo("[RECORDER] 🔴 Stop recording. Plotting path...")
        recording = False
        plot_path()


def plot_path():
    if not x_positions or not y_positions:
        rospy.logwarn("[RECORDER] No path data to plot!")
        return

    plt.figure(figsize=(8, 6))
    plt.plot(x_positions, y_positions, marker='o', linestyle='-', label="Car Path")
    plt.xlabel("X Position (m)")
    plt.ylabel("Y Position (m)")
    plt.title("Recorded Vehicle Path")
    plt.legend()
    plt.grid(True)
    plt.axis('equal')
    plt.show()


def process_pose(event):
    global latest_msg, recording

    if not recording or not latest_msg:
        return

    try:
        index = latest_msg.name.index("ackermann_vehicle")
        pose = latest_msg.pose[index]

        x = pose.position.x
        y = pose.position.y

        x_positions.append(x)
        y_positions.append(y)

    except ValueError:
        rospy.logwarn("ackermann_vehicle not found in model_states!")


if __name__ == '__main__':
    rospy.init_node('path_recorder')

    rospy.Subscriber('/gazebo/model_states', ModelStates, model_states_callback)
    rospy.Subscriber('/path_recorder_command', String, command_callback)

    rospy.Timer(rospy.Duration(0.1), process_pose)  # Check every 0.1s (10Hz)

    rospy.loginfo("[RECORDER] Ready to record! Send 'start' or 'stop' to /path_recorder_command.")
    rospy.spin()
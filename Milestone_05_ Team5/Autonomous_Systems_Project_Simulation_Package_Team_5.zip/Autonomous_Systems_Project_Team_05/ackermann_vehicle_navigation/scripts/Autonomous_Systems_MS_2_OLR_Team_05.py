#!/usr/bin/env python3

# Original Author: christoph.roesmann@tu-dortmund.de
# aizzat: Updated python3 path for compatibility
# If issues arise, you may replace '#!/usr/bin/env python3' with '#!/usr/bin/env python'

import rospy
import math
from geometry_msgs.msg import Twist
from ackermann_msgs.msg import AckermannDriveStamped, AckermannDrive

# Function to convert linear and angular velocity to steering angle using Ackermann geometry
def convert_trans_rot_vel_to_steering_angle(v, omega, wheelbase):
    if omega == 0 or v == 0:
        return 0  # No rotation or no speed means no steering
    radius = v / omega
    return math.atan(wheelbase / radius)

# Callback for incoming Twist messages (usually from /cmd_vel)
def cmd_callback(data):
    global wheelbase, ackermann_cmd_topic, frame_id, pub, message_type

    v = data.linear.x  # Forward velocity
    omega = data.angular.z  # Angular velocity (yaw rate)

    # Convert to steering angle
    steering = convert_trans_rot_vel_to_steering_angle(v, omega, wheelbase)

    # Depending on message type, publish appropriate Ackermann message
    if message_type == 'ackermann_drive':
        msg = AckermannDrive()
        msg.steering_angle = steering
        msg.speed = v
        pub.publish(msg)  # Publish to topic
    else:
        msg = AckermannDriveStamped()
        msg.header.stamp = rospy.Time.now()  # Add timestamp
        msg.header.frame_id = frame_id       # Add frame ID
        msg.drive.steering_angle = steering
        msg.drive.speed = v
        pub.publish(msg)

if __name__ == '__main__': 
    try:
        # Initialize ROS node
        rospy.init_node('Autonomous_Systems_MS_2_OLR_Team_05')
        
        # Get parameters from launch file or command line, with default values
        twist_cmd_topic = rospy.get_param('~twist_cmd_topic', '/cmd_vel') 
        ackermann_cmd_topic = rospy.get_param('~ackermann_cmd_topic', '/ackermann_cmd')
        wheelbase = rospy.get_param('~wheelbase', 1.0)
        frame_id = rospy.get_param('~frame_id', 'odom')
        message_type = rospy.get_param('~message_type', 'ackermann_drive')  # Choose message format

        # Subscribe to Twist topic (velocity commands)
        rospy.Subscriber(twist_cmd_topic, Twist, cmd_callback, queue_size=1)

        # Create publisher based on message type
        if message_type == 'ackermann_drive':
            pub = rospy.Publisher(ackermann_cmd_topic, AckermannDrive, queue_size=1)
        else:
            pub = rospy.Publisher(ackermann_cmd_topic, AckermannDriveStamped, queue_size=1)

        # Log info for user
        rospy.loginfo("Node 'cmd_vel_to_ackermann_drive' started.\nListening to %s, publishing to %s. Frame id: %s, wheelbase: %f", 
                      twist_cmd_topic, ackermann_cmd_topic, frame_id, wheelbase)

        # Keep the node alive
        rospy.spin()

    except rospy.ROSInterruptException:
        pass

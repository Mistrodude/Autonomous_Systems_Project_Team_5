#!/usr/bin/env python3
import rospy
import random
from gazebo_msgs.msg import ModelStates
from std_msgs.msg import Float64

def noise_callback(msg):
    # Retrieve noise parameters
    pos_std = rospy.get_param('~pos_noise_std', 0.02)
    vel_std = rospy.get_param('~vel_noise_std', 0.01)
    seed    = rospy.get_param('~noise_seed', None)
    if seed is not None:
        random.seed(seed)

    for i, name in enumerate(msg.name):
        if name == 'ackermann_vehicle':
            # ---- Capture the raw (true) measurements ----
            vx_true = msg.twist[i].linear.x
            vy_true = msg.twist[i].linear.y
            true_speed = vx_true  # or compute sqrt(vx_true**2 + vy_true**2)

            # Publish raw velocity
            raw_vel_pub.publish(Float64(data=true_speed))
            rospy.loginfo("[BEFORE NOISE] vx: %.3f", true_speed)

            # ---- Inject Gaussian noise ----
            vx_noisy = vx_true + random.gauss(0.0, vel_std)
            vy_noisy = vy_true + random.gauss(0.0, vel_std)
            noisy_speed = vx_noisy  # or compute sqrt(vx_noisy**2 + vy_noisy**2)

            # Overwrite the message with noisy values (if you still need it)
            msg.twist[i].linear.x = vx_noisy
            msg.twist[i].linear.y = vy_noisy

            # Publish noisy velocity
            noisy_vel_pub.publish(Float64(data=noisy_speed))
            rospy.loginfo("[ AFTER NOISE] vx: %.3f", noisy_speed)

            break  # only noise the first matching model

    noisy_pub.publish(msg)

if __name__ == '__main__':
    rospy.init_node('Localization', anonymous=False)

    # Publisher for the full noisy ModelStates (unchanged)
    noisy_pub = rospy.Publisher(
        '/noisy_model_states',
        ModelStates,
        queue_size=1
    )

    # NEW: Publishers for velocity (Float64) before and after noise
    raw_vel_pub   = rospy.Publisher('/vehicle_velocity_raw',   Float64, queue_size=1)
    noisy_vel_pub = rospy.Publisher('/vehicle_velocity_noisy', Float64, queue_size=1)

    # Subscribe to the real Gazebo model states
    rospy.Subscriber(
        '/gazebo/model_states',
        ModelStates,
        noise_callback,
        queue_size=1
    )

    rospy.loginfo("Localization node started: publishing raw & noisy velocities and /noisy_model_states")
    rospy.spin()

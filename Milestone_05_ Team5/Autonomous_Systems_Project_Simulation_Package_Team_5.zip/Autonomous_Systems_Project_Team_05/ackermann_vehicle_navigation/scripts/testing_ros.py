#!/usr/bin/env python3
import rospy
import math
from geometry_msgs.msg import Twist
from ackermann_msgs.msg import AckermannDriveStamped, AckermannDrive

def convert_trans_rot_vel_to_steering_angle(v, omega, wheelbase):
    if omega == 0 or v == 0:
        return 0  # No rotation or no speed means no steering
    radius = v / omega
    return math.atan(wheelbase / radius)

def callback(data):
        #Define global variables 
        global wheelbase, ackermann_cmd_topic, frame_id, pub, message_type
        # Callback function to handle incoming messages
        v= data.linear.x  # Forward velocity
        omega=data.angular.z  # Angular velocity (yaw rate)
        steering= convert_trans_rot_vel_to_steering_angle(v, omega, wheelbase)#function to calculate steering angle
        #put the velocity and steering angle in the message
        if message_type=='ackermann_drive':
              msg= AckermannDrive()
              msg.speed= v
              msg.steering_angle= steering
              pub.publish(msg)
        else:
              msg= AckermannDriveStamped()
              msg.header.stamp= rospy.Time.now()
              msg.header.frame_id= frame_id
              msg.drive.steering_angle= steering
              msg.drive.speed= v
              pub.publish(msg)
        



       

if __name__ == '__main__':
   try:
        # Initialize the ROS node
        rospy.init_node('tester')
        # Get parameters from the launch file or command line
        twist_cmd_topic= rospy.get_param('~twist_cmd_topic', '/cmd_vel')
        ackermann_cmd_topic= rospy.get_param('~ackermann_cmd_topic', '/ackermann_cmd')
        wheelbase= rospy.get_param('~wheelbase', 1.0)
        frame_id= rospy.get_param('~frame_id', 'odom')
        message_type= rospy.get_param('~message_type', 'ackermann_drive')  # Choose message format

        # Subscribe to the Twist topic (velocity commands)
        rospy.Subscriber(twist_cmd_topic, Twist, callback, queue_size=1)
        # Create publisher based on message type
        if message_type=='ackermann_drive':
              pub= rospy.Publisher(ackermann_cmd_topic, AckermannDrive, queue_size=1)
        else:
          pub=rospy.Publisher(ackermann_cmd_topic, AckermannDriveStamped, queue_size=1)
        # Log information for the user
        rospy.loginfo("Listening to %s and publishing to %s", twist_cmd_topic, ackermann_cmd_topic)
        rospy.loginfo("Wheelbase: %f", wheelbase)
        rospy.loginfo("Message type: %s", message_type)
        # Spin to keep the node running
        rospy.spin()
        # rospy.spin()
   except rospy.ROSInterruptException:
        pass


    
                         
                         


       
    
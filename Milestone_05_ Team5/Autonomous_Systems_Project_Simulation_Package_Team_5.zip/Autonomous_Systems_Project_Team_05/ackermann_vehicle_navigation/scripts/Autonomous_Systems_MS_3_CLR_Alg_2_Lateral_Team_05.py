#!/usr/bin/env python3

import rospy
import math
import numpy as np
from gazebo_msgs.msg import ModelStates
from ackermann_msgs.msg import AckermannDrive
from std_msgs.msg import Float32
from tf.transformations import euler_from_quaternion

# --- Parameters ---
k = 0.7                   # Reduced base gain (originally 1.0)
softening_factor = 8.0    # Softens cross-track error response
epsilon = 0.1
min_speed = 0.2           # Minimum speed for steering calculations
max_steering_deg = 25     # Maximum steering angle (degrees)

# --- Global variables ---
ackermann_pub = None
cte_pub       = None
latest_msg    = None
target_index  = 0

# --- Path waypoints ---
path = np.array([
    [-0.3, 2],
    [-0.3, 4.5],
    [ 0.35, 5.6],
    [ 0.35, 8],
    [ 0.35, 11.5],
    [-0.3, 13],
    [-0.3, 16]
])

def get_yaw(q):
    """Convert quaternion to yaw (heading)."""
    return euler_from_quaternion([q.x, q.y, q.z, q.w])[2]

def stanley_control(x, y, yaw, v):
    """Compute steering angle using the Stanley method."""
    global target_index

    # If we've reached the end of the path, return zero steering
    if target_index >= len(path):
        return 0.0

    # Compute vector to current waypoint
    tx, ty = path[target_index]
    dx, dy = tx - x, ty - y
    dist = math.hypot(dx, dy)

    # Advance to next waypoint if close enough
    if dist < 0.5 and target_index < len(path) - 1:
        rospy.loginfo(f"[ADVANCE] Reached waypoint {target_index}, moving to {target_index+1}")
        target_index += 1
        tx, ty = path[target_index]
        dx, dy = tx - x, ty - y

    # Heading error
    path_heading = math.atan2(dy, dx)
    theta_e = math.atan2(math.sin(path_heading - yaw), math.cos(path_heading - yaw))

    # Softened cross-track error
    cte = np.cross([math.cos(yaw), math.sin(yaw)], [dx, dy])
    cte = cte / (softening_factor + abs(cte))

    # Publish CTE
    cte_msg = Float32()
    cte_msg.data = cte
    cte_pub.publish(cte_msg)
    rospy.loginfo(f"[CROSS-TRACK ERROR] {cte:.4f} m")

    # Dynamic gain (slower at higher speed)
    v_safe = max(v, min_speed)
    k_dyn = k / (1.0 + 0.1 * v_safe)

    # Stanley formula
    delta = theta_e + math.atan2(k_dyn * cte, v_safe)

    # Simple low-pass filter on steering
    if not hasattr(stanley_control, 'prev_delta'):
        stanley_control.prev_delta = delta
    delta = 0.3 * delta + 0.7 * stanley_control.prev_delta
    stanley_control.prev_delta = delta

    # Clip to max steering
    max_rad = math.radians(max_steering_deg)
    delta = np.clip(delta, -max_rad, max_rad)

    rospy.loginfo(f"[STEERING] {math.degrees(delta):.1f}° at {v:.2f} m/s (gain {k_dyn:.2f})")
    return delta

def filtered_states_callback(msg):
    """Cache the latest filtered ModelStates message."""
    global latest_msg
    latest_msg = msg

def control_callback(event):
    """Timer callback: run Stanley control and publish steering."""
    global latest_msg

    if not latest_msg:
        return

    try:
        idx = latest_msg.name.index("ackermann_vehicle")
        pose  = latest_msg.pose[idx]
        twist = latest_msg.twist[idx]

        x   = pose.position.x
        y   = pose.position.y
        yaw = get_yaw(pose.orientation)
        v   = math.hypot(twist.linear.x, twist.linear.y)

        # Compute steering
        steering = stanley_control(x, y, yaw, v)

        # Publish as AckermannDrive (only steering_angle used)
        cmd = AckermannDrive()
        cmd.steering_angle = steering
        ackermann_pub.publish(cmd)

    except ValueError:
        rospy.logwarn("ackermann_vehicle not found in filtered_model_states!")

if __name__ == '__main__':
    rospy.init_node('stanley_path_follower')

    # Publish desired steering and CTE
    ackermann_pub = rospy.Publisher("/desired_steering", AckermannDrive, queue_size=10)
    cte_pub       = rospy.Publisher("/cross_track_error", Float32, queue_size=10)

    # --- CHANGE HERE: subscribe to filtered data instead of raw Gazebo ---
    rospy.Subscriber(
        '/filtered_model_states',  # <-- filtered topic
        ModelStates,
        filtered_states_callback,
        queue_size=1
    )

    # Run control loop at 10 Hz (0.1 s)
    rospy.Timer(rospy.Duration(0.1), control_callback)
    rospy.spin()

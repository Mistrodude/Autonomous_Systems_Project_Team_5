#!/usr/bin/env python3

import rospy
import math
import numpy as np
from gazebo_msgs.msg import ModelStates
from ackermann_msgs.msg import AckermannDrive
from tf.transformations import euler_from_quaternion

# --- PID parameters ---
Kp = 1
Ki = 0.1
Kd = 0.05
error = 0
error_prev = 0
int_prev = 0

# --- Stanley parameters ---
k = 1
epsilon = 0.1

# --- Waypoint ---
target_point = (10, -10)
path = np.array([[10, -10]])

# --- State ---
latest_msg = None
ackermann_pub = None

def get_yaw(q):
    return euler_from_quaternion([q.x, q.y, q.z, q.w])[2]

def closest_point_and_heading(x, y):
    dists = np.linalg.norm(path - np.array([x, y]), axis=1)
    idx = np.argmin(dists)
    closest = path[idx]
    next_pt = path[min(idx + 1, len(path) - 1)]
    heading = math.atan2(next_pt[1] - closest[1], next_pt[0] - closest[0])
    return closest, heading

def stanley_control(x, y, yaw, v):
    closest, path_heading = closest_point_and_heading(x, y)
    theta_e = path_heading - yaw
    theta_e = math.atan2(math.sin(theta_e), math.cos(theta_e))

    dx = closest[0] - x
    dy = closest[1] - y
    cross_track_error = dy * math.cos(path_heading) - dx * math.sin(path_heading)

    delta = theta_e + math.atan2(k * cross_track_error, v + epsilon)
    max_steering_deg = 25
    max_steering_rad = math.radians(max_steering_deg)
    delta = max(-max_steering_rad, min(max_steering_rad, delta))

    return delta

def pid_speed_control(desired_speed, actual_speed):
    global error, error_prev, int_prev

    error = desired_speed - actual_speed
    xi = int_prev + 0.5 * (error + error_prev) * 0.1
    xd = (error - error_prev) / 0.1
    output = Kp * error + Ki * xi + Kd * xd

    int_prev = xi
    error_prev = error

    return output

def model_states_callback(msg):
    global latest_msg
    latest_msg = msg

def control_loop(event):
    global latest_msg

    if not latest_msg:
        return

    try:
        idx = latest_msg.name.index("ackermann_vehicle")
        pose = latest_msg.pose[idx]
        twist = latest_msg.twist[idx]

        x = pose.position.x
        y = pose.position.y
        yaw = get_yaw(pose.orientation)
        v = math.sqrt(twist.linear.x**2 + twist.linear.y**2)

        # --- Stanley ---
        delta = stanley_control(x, y, yaw, v)

        # --- PID Speed ---
        distance = math.sqrt((x - target_point[0])**2 + (y - target_point[1])**2)
        if distance > 5.0:
            desired_speed = 2.0
        elif distance > 1.0:
            desired_speed = 0.5
        else:
            desired_speed = 0.0

        speed = pid_speed_control(desired_speed, v)

        # --- Publish AckermannDrive ---
        msg = AckermannDrive()
        msg.steering_angle = delta
        msg.speed = speed
        ackermann_pub.publish(msg)

        # --- Debug logs ---
        rospy.loginfo(f"[STATE] x={x:.2f} y={y:.2f} yaw={yaw:.2f} v={v:.2f}")
        rospy.loginfo(f"[CONTROL] Steering={math.degrees(delta):.2f}° | Speed={speed:.2f} m/s")

    except ValueError:
        rospy.logwarn("ackermann_vehicle not found in model_states!")

if __name__ == '__main__':
    rospy.init_node('combined_pid_stanley_controller')

    ackermann_pub = rospy.Publisher('/ackermann_cmd', AckermannDrive, queue_size=1)
    rospy.Subscriber('/gazebo/model_states', ModelStates, model_states_callback)

    rospy.Timer(rospy.Duration(0.1), control_loop)
    rospy.spin()
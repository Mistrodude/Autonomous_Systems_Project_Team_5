#!/usr/bin/env python3
import rospy
import numpy as np
from gazebo_msgs.msg import ModelStates

class LocalizationKF:
    def __init__(self):
        # --- ROS setup ---
        rospy.init_node('Localization_KF')
        self.pub = rospy.Publisher('/filtered_model_states', ModelStates, queue_size=1)
        rospy.Subscriber('/noisy_model_states', ModelStates, self.cb, queue_size=1)

        # --- Filter state ---
        # state x = [x, y, vx, vy]^T
        self.x = np.zeros((4, 1))
        self.P = np.eye(4) * 0.1

        # --- Timing ---
        self.dt = rospy.get_param('~dt', 0.1)

        # --- Motion & observation models ---
        self.F = np.array([
            [1, 0, self.dt,    0],
            [0, 1,     0, self.dt],
            [0, 0,     1,      0],
            [0, 0,     0,      1]
        ])
        self.H = np.eye(4)

        # --- Noise covariances ---
        q_pos = rospy.get_param('~process_noise_pos', 0.01)
        q_vel = rospy.get_param('~process_noise_vel', 0.1)
        self.Q = np.diag([q_pos, q_pos, q_vel, q_vel])

        r_pos = rospy.get_param('~meas_noise_pos', 0.02)
        r_vel = rospy.get_param('~meas_noise_vel', 0.01)
        self.R = np.diag([r_pos, r_pos, r_vel, r_vel])

        rospy.loginfo("Localization_KF initialized; waiting for /noisy_model_states...")

    def cb(self, msg):
        # 1) Extract the noisy measurement z = [x, y, vx, vy]
        try:
            idx = msg.name.index('ackermann_vehicle')
        except ValueError:
            return

        z = np.array([
            [msg.pose[idx].position.x],
            [msg.pose[idx].position.y],
            [msg.twist[idx].linear.x],
            [msg.twist[idx].linear.y]
        ])

        # Log the raw (noisy) measurement
        rospy.loginfo(
            "[KF INPUT ]  x: %.3f, y: %.3f, vx: %.3f, vy: %.3f",
            z[0,0], z[1,0], z[2,0], z[3,0]
        )

        # 2a) PREDICT
        x_pred = self.F.dot(self.x)
        P_pred = self.F.dot(self.P).dot(self.F.T) + self.Q

        # 2b) UPDATE
        S = self.H.dot(P_pred).dot(self.H.T) + self.R
        K = P_pred.dot(self.H.T).dot(np.linalg.inv(S))
        y = z - self.H.dot(x_pred)
        self.x = x_pred + K.dot(y)
        self.P = (np.eye(4) - K.dot(self.H)).dot(P_pred)

        # Log the filtered (post-update) state
        rospy.loginfo(
            "[KF OUTPUT]  x: %.3f, y: %.3f, vx: %.3f, vy: %.3f",
            float(self.x[0,0]), float(self.x[1,0]),
            float(self.x[2,0]), float(self.x[3,0])
        )

        # 3) Inject filtered state back into the ModelStates message
        msg.pose[idx].position.x = float(self.x[0,0])
        msg.pose[idx].position.y = float(self.x[1,0])
        msg.twist[idx].linear.x    = float(self.x[2,0])
        msg.twist[idx].linear.y    = float(self.x[3,0])

        # 4) Publish
        self.pub.publish(msg)

    def run(self):
        rospy.spin()

if __name__ == '__main__':
    node = LocalizationKF()
    node.run()

#!/usr/bin/env python3

import rospy
from gazebo_msgs.srv import DeleteModel, SpawnModel
from geometry_msgs.msg import Pose

def reset_model():
    model_name = "ackermann_vehicle"  # Same name used in your launch file

    # Get the robot_description param (URDF content)
    rospy.loginfo("Getting robot_description...")
    if not rospy.has_param("/robot_description"):
        rospy.logerr("/robot_description not set. Aborting.")
        return

    model_xml = rospy.get_param("/robot_description")

    # Delete the model
    rospy.wait_for_service('/gazebo/delete_model')
    try:
        delete_srv = rospy.ServiceProxy('/gazebo/delete_model', DeleteModel)
        delete_srv(model_name)
        rospy.loginfo("Model deleted successfully.")
    except rospy.ServiceException as e:
        rospy.logwarn("Model deletion failed: %s" % e)

    # Spawn the model at original pose
    rospy.wait_for_service('/gazebo/spawn_urdf_model')
    try:
        spawn_srv = rospy.ServiceProxy('/gazebo/spawn_urdf_model', SpawnModel)
        pose = Pose()
        pose.position.x = 0.0
        pose.position.y = 0.0
        pose.position.z = 0.1
        pose.orientation.w = 1.0

        spawn_srv(model_name, model_xml, "/", pose, "world")
        rospy.loginfo("Model respawned successfully.")
    except rospy.ServiceException as e:
        rospy.logerr("Model spawn failed: %s" % e)

if __name__ == "__main__":
    rospy.init_node("reset_ackermann_vehicle")
    rospy.sleep(1.0)
    reset_model()


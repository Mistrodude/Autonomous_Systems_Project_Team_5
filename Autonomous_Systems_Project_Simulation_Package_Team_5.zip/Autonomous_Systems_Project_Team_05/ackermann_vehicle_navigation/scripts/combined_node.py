#!/usr/bin/env python3

import rospy
import math
import numpy as np
from gazebo_msgs.msg import ModelStates
from ackermann_msgs.msg import AckermannDrive
from tf.transformations import euler_from_quaternion

# PID parameters
Kp = 1.5
Ki = 0.1
Kd = 0.05
error = 0
error_prev = 0
int_prev = 0

# Stanley parameters
k = 1.5
epsilon = 0.1

# Path (Zigzag for testing)
path = np.array([
    [8, 11],
    [10, 8],
    [12, 5],
    [14, 2],
    [16, 0],
    [18, -2],
    [20, -5],
    [22, -8],
    [24, -10]
])

# State
latest_msg = None
ackermann_pub = None
path_completed = False

def get_yaw(q):
    return euler_from_quaternion([q.x, q.y, q.z, q.w])[2]

def closest_point_and_heading(x, y):
    dists = np.linalg.norm(path - np.array([x, y]), axis=1)
    idx = np.argmin(dists)
    closest = path[idx]

    # Choose a look-ahead point for heading
    lookahead_idx = min(idx + 1, len(path) - 1)
    next_pt = path[lookahead_idx]

    heading = math.atan2(next_pt[1] - closest[1], next_pt[0] - closest[0])
    return closest, heading

def stanley_control(x, y, yaw, v):
    closest, path_heading = closest_point_and_heading(x, y)

    dx = closest[0] - x
    dy = closest[1] - y
    cross_track_error = dy * math.cos(path_heading) - dx * math.sin(path_heading)

    theta_e = path_heading - yaw
    theta_e = math.atan2(math.sin(theta_e), math.cos(theta_e))

    delta = theta_e + math.atan2(k * cross_track_error, v + epsilon)

    max_steering_rad = math.radians(25)
    delta = max(-max_steering_rad, min(max_steering_rad, delta))
    return delta

def pid_speed_control(desired_speed, actual_speed):
    global error, error_prev, int_prev

    error = desired_speed - actual_speed
    xi = int_prev + 0.5 * (error + error_prev) * 0.1
    xd = (error - error_prev) / 0.1
    output = Kp * error + Ki * xi + Kd * xd

    int_prev = xi
    error_prev = error

    return max(0.0, output)  # prevent reversing

def model_states_callback(msg):
    global latest_msg
    latest_msg = msg

def control_loop(event):
    global latest_msg, path_completed

    if not latest_msg or path_completed:
        return

    try:
        idx = latest_msg.name.index("ackermann_vehicle")
        pose = latest_msg.pose[idx]
        twist = latest_msg.twist[idx]

        x = pose.position.x
        y = pose.position.y
        yaw = get_yaw(pose.orientation)
        v = math.sqrt(twist.linear.x**2 + twist.linear.y**2)

        # Distance to final point
        final_point = path[-1]
        distance = math.sqrt((x - final_point[0])**2 + (y - final_point[1])**2)

        # Determine desired speed
        if distance > 5.0:
            desired_speed = 2.0
        elif distance > 1.0:
            desired_speed = 0.5
        else:
            desired_speed = 0.0
            path_completed = True
            rospy.loginfo("🎯 Path completed. Vehicle stopping.")
        
        # Control
        delta = stanley_control(x, y, yaw, v)
        speed = pid_speed_control(desired_speed, v)

        # Publish
        msg = AckermannDrive()
        msg.steering_angle = delta
        msg.speed = speed
        ackermann_pub.publish(msg)

        rospy.loginfo(f"[STATE] x={x:.2f} y={y:.2f} yaw={yaw:.2f} v={v:.2f}")
        rospy.loginfo(f"[CONTROL] Steering={math.degrees(delta):.2f}° | Speed={speed:.2f} m/s | Dist={distance:.2f}")

    except ValueError:
        rospy.logwarn("ackermann_vehicle not found in model_states!")

if __name__ == '__main__':
    rospy.init_node('combined_pid_stanley_controller')

    ackermann_pub = rospy.Publisher('/ackermann_cmd', AckermannDrive, queue_size=1)
    rospy.Subscriber('/gazebo/model_states', ModelStates, model_states_callback)

    rospy.Timer(rospy.Duration(0.1), control_loop)
    rospy.spin()

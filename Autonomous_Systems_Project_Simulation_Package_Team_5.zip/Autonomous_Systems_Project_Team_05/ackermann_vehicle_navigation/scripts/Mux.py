#!/usr/bin/env python3

import rospy
from ackermann_msgs.msg import AckermannDrive
from std_msgs.msg import Float32

# Global variables for latest values
latest_speed = 0.0
latest_steering = 0.0

def speed_callback(msg):
    global latest_speed
    latest_speed = msg.data  # <-- because /control_output is Float32

def steering_callback(msg):
    global latest_steering
    latest_steering = msg.steering_angle  # <-- still from desired_steering topic

def publisher_loop():
    pub = rospy.Publisher("/ackermann_cmd", AckermannDrive, queue_size=10)
    rate = rospy.Rate(10)  # 10 Hz

    while not rospy.is_shutdown():
        msg = AckermannDrive()
        msg.speed = latest_speed
        msg.steering_angle = latest_steering
        pub.publish(msg)
        rate.sleep()

def main():
    rospy.init_node("ackermann_mux")

    rospy.Subscriber("/control_output", Float32, speed_callback)        # <-- subscribe to control output
    rospy.Subscriber("/desired_steering", AckermannDrive, steering_callback)  # <-- subscribe to steering

    publisher_loop()

if __name__ == '__main__':
    main()

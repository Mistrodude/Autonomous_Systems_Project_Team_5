#!/usr/bin/env python3

import rospy
import math
import numpy as np
from gazebo_msgs.msg import ModelStates
from std_msgs.msg import Float32
from ackermann_msgs.msg import AckermannDrive  # still needed because desired_speed is an AckermannDrive

# --- PID constants ---
Kp = 0.8
Ki = 0.2
Kd = 0.002
error = 0
error_prev = 0
int_prev = 0

# --- Parameters ---
MAX_SPEED = 2.0       # Maximum allowed speed (m/s)

# --- Global variables ---
desired_speed = 0.0    # Received from desired_speed_control node
control_output_pub = None
latest_msg = None

# --- Path waypoints ---
path = np.array([[-0.3, 2], [-0.3, 4.5], [0.35, 5.6], [0.35, 8], [0.35, 11.5], [-0.3, 13], [-0.3, 16]])
current_index = 0

def desired_speed_callback(msg):
    global desired_speed
    desired_speed = msg.speed  # Only care about speed field

def control_output(desired_speed, actual_speed):
    global error, error_prev, int_prev

    error = desired_speed - actual_speed
    xi = int_prev + 0.5 * (error + error_prev) * 0.1  # Integral term (0.1s timestep)
    xd = (error - error_prev) / 0.1                   # Derivative term
    output = (Kp * error) + (Ki * xi) + (Kd * xd)

    # Anti-windup for integral term
    int_prev = np.clip(xi, -MAX_SPEED, MAX_SPEED)
    error_prev = error

    # Publish control output to /control_output topic
    control_msg = Float32()
    control_msg.data = output
    control_output_pub.publish(control_msg)

    rospy.loginfo(f"[PID OUTPUT] Desired: {desired_speed:.2f} m/s | Actual: {actual_speed:.2f} m/s | PID Output: {output:.2f} m/s")

def model_states_callback(msg):
    global latest_msg
    latest_msg = msg

def process_speed(event):
    global latest_msg, current_index

    if not latest_msg or current_index >= len(path):
        return

    try:
        index = latest_msg.name.index("ackermann_vehicle")
        pose = latest_msg.pose[index]
        twist = latest_msg.twist[index]

        x = pose.position.x
        y = pose.position.y
        linear_x = twist.linear.x
        linear_y = twist.linear.y
        actual_speed = math.sqrt(linear_x**2 + linear_y**2)

        # Current waypoint
        target_x, target_y = path[current_index]
        distance = math.sqrt((x - target_x)**2 + (y - target_y)**2)

        rospy.loginfo(f"[WAYPOINT {current_index}] 📍 ({target_x}, {target_y}) | Distance = {distance:.2f} m")

        # Waypoint advancement logic
        if distance <= 0.5 and current_index < len(path) - 1:
            current_index += 1
            rospy.loginfo(f"[ADVANCING] ➡️ Moving to waypoint {current_index}")

        # Send to PID controller
        control_output(desired_speed, actual_speed)

    except ValueError:
        rospy.logwarn("ackermann_vehicle not found in model_states!")

if __name__ == '__main__':
    rospy.init_node('pid_speed_controller')

    control_output_pub = rospy.Publisher("/control_output", Float32, queue_size=10)
    rospy.Subscriber('/gazebo/model_states', ModelStates, model_states_callback)
    rospy.Subscriber('/desired_speed', AckermannDrive, desired_speed_callback)

    rospy.sleep(0.5)
    rospy.Timer(rospy.Duration(0.1), process_speed)
    rospy.spin()

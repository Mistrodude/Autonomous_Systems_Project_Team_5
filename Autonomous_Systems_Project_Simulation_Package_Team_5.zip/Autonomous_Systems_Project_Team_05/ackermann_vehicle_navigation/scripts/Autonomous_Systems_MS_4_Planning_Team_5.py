#!/usr/bin/env python3

import rospy
import math
from std_msgs.msg import Float32
from ackermann_msgs.msg import AckermannDrive


# --- Parameters ---
MAX_SPEED = 1.5          # Max speed (m/s)
MIN_SPEED = 0.2          # Min speed when large cross-track error
MAX_ACCEL = 0.5         # Max acceleration (m/s²)
MAX_DECEL = 1          # Max deceleration (m/s²)
UPDATE_RATE = 20        # Hz (every 0.1s)

# --- Global variables ---
current_desired_speed = 0.0  # Current smooth speed
latest_cte = 0.0             # Latest cross track error

# Publisher
desired_speed_pub = None

def cte_callback(msg):
    global latest_cte
    latest_cte = abs(msg.data)  # Use absolute value of CTE

def compute_target_speed(cte):
    """
    Define target speed based on how far we are from the path center.
    Smaller CTE → higher speed. Larger CTE → lower speed.
    """
    if abs(cte) < 0.008:
        return 1.4
    elif abs(cte) < 0.10:
        return 0.3
    elif abs(cte) < 0.2:
        return 0.15



def update_desired_speed(event):
    global current_desired_speed

    # Determine target speed based on current CTE
    target_speed = compute_target_speed(latest_cte)

    # Calculate timestep
    dt = 1.0 / UPDATE_RATE

    # Adjust current_desired_speed toward target_speed with limits
    if target_speed > current_desired_speed:
        # Accelerate
        current_desired_speed = min(
            current_desired_speed + MAX_ACCEL * dt,
            target_speed,
            MAX_SPEED
        )
    else:
        # Decelerate
        current_desired_speed = max(
            current_desired_speed - MAX_DECEL * dt,
            target_speed,
            MIN_SPEED
        )

    # Publish the updated desired speed
    msg = AckermannDrive()
    msg.speed = current_desired_speed
    desired_speed_pub.publish(msg)

    rospy.loginfo(f"[DESIRED SPEED] Target: {target_speed:.2f} m/s | Smoothed: {current_desired_speed:.2f} m/s | CTE: {latest_cte:.2f} m")

if __name__ == '__main__':
    rospy.init_node('desired_speed_control')

    desired_speed_pub = rospy.Publisher('/desired_speed', AckermannDrive, queue_size=10)
    rospy.Subscriber('/cross_track_error', Float32, cte_callback)

    rospy.Timer(rospy.Duration(1.0 / UPDATE_RATE), update_desired_speed)

    rospy.spin()

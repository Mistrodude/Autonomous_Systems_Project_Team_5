^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ackermann_vehicle_description
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.3 (2015-09-18)
------------------
* Added some run_depend elements.
* Added a copyright comment.

0.1.2 (2015-08-19)
------------------
* Launch and URDF files are now installed.

0.1.1 (2014-09-26)
------------------
* Added hardwareInterface elements to the URDF file in order to make it
  compatible with ROS Hydro and Indigo.

0.1.0 (2014-09-18)
------------------
* Initial release.

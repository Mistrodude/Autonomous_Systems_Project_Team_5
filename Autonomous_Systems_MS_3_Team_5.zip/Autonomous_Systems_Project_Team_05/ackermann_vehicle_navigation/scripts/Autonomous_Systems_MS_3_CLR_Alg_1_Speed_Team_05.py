#!/usr/bin/env python3

import rospy
import math
import numpy as np
from gazebo_msgs.msg import ModelStates
from ackermann_msgs.msg import AckermannDrive

# PID constants
Kp = 1
Ki = 0.3
Kd = 0.1
error = 0
error_prev = 0
int_prev = 0

# Speed control parameters
MAX_SPEED = 2       # Maximum allowed speed (m/s)
MAX_ACCEL = 0.5       # Acceleration limit (m/s²)
MAX_DECEL = 1.5       # Deceleration can be more aggressive if needed
current_desired_speed = 0.0  # Tracks the ramped speed

# Path waypoints
path = np.array([[8, 8], [8, 10], [8, 12], [10, 16], [12, 16], [20, 16]])
current_index = 0

# Publisher
ackermann_pub = None
latest_msg = None

def control_output(desired_speed, actual_speed):
    global error, error_prev, int_prev

    error = desired_speed - actual_speed
    xi = int_prev + 0.5 * (error + error_prev) * 0.1  # Integral term (0.1s timestep)
    xd = (error - error_prev) / 0.1                   # Derivative term
    output = Kp * error + Ki * xi + Kd * xd

    # Anti-windup for integral term
    int_prev = np.clip(xi, -MAX_SPEED, MAX_SPEED)
    error_prev = error

    msg = AckermannDrive()
    msg.speed = np.clip(output, -0.5, MAX_SPEED)  # Clamp final output
    ackermann_pub.publish(msg)

def model_states_callback(msg):
    global latest_msg
    latest_msg = msg

def process_speed(event):
    global latest_msg, current_index, current_desired_speed

    if not latest_msg or current_index >= len(path):
        return

    try:
        index = latest_msg.name.index("ackermann_vehicle")
        pose = latest_msg.pose[index]
        twist = latest_msg.twist[index]

        x = pose.position.x
        y = pose.position.y
        linear_x = twist.linear.x
        linear_y = twist.linear.y
        actual_speed = math.sqrt(linear_x**2 + linear_y**2)

        # Current waypoint
        target_x, target_y = path[current_index]
        distance = math.sqrt((x - target_x)**2 + (y - target_y)**2)

        rospy.loginfo(f"[WAYPOINT {current_index}] 📍 ({target_x}, {target_y}) | Distance = {distance:.2f} m")

        # Waypoint advancement logic
        if distance <= 0.5:
            current_index += 1
            rospy.loginfo(f"[ADVANCING] ➡️ Moving to waypoint {current_index}")
            return

        # Original target speed logic
        target_speed = MAX_SPEED if distance > 3.0 else 0.5

        # Apply acceleration/deceleration limits
        if target_speed > current_desired_speed:
            # Accelerate
            current_desired_speed = min(
                current_desired_speed + MAX_ACCEL * 0.1,  # 0.1s timestep
                target_speed,
                MAX_SPEED
            )
        else:
            # Decelerate
            current_desired_speed = max(
                current_desired_speed - MAX_DECEL * 0.1,
                target_speed
            )

        rospy.loginfo(f"[SPEED] Target: {target_speed:.2f} | Ramped: {current_desired_speed:.2f} | Actual: {actual_speed:.2f} m/s")

        # Send to PID controller
        control_output(current_desired_speed, actual_speed)

    except ValueError:
        rospy.logwarn("ackermann_vehicle not found in model_states!")

if __name__ == '__main__':
    rospy.init_node('path_follower_controller')

    ackermann_pub = rospy.Publisher("/desired_speed", AckermannDrive, queue_size=10)
    rospy.Subscriber('/gazebo/model_states', ModelStates, model_states_callback)

    rospy.sleep(0.5)
    rospy.Timer(rospy.Duration(0.1), process_speed)
    rospy.spin()
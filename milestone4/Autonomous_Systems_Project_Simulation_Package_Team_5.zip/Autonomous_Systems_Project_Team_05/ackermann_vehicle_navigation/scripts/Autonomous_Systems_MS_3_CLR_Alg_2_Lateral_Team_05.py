#!/usr/bin/env python3

import rospy
import math
import numpy as np
from gazebo_msgs.msg import ModelStates
from ackermann_msgs.msg import AckermannDrive
from std_msgs.msg import Float32  # Added for publishing CTE
from tf.transformations import euler_from_quaternion

# --- Parameters ---
k = 0.7       # Reduced base gain (originally 1.0)
softening_factor = 8.0  # Softens cross-track error response
epsilon = 0.1
min_speed = 0.2         # Minimum speed for steering calculations
max_steering_deg = 25   # Maximum steering angle (degrees)

# --- Global variables ---
ackermann_pub = None
cte_pub = None           # Cross-track error publisher
latest_msg = None
target_index = 0

# --- Path waypoints ---
path = np.array([[-0.3, 2], [-0.3, 4.5], [0.35, 5.6], [0.35, 8], [0.35, 11.5], [-0.3, 13], [-0.3, 16]])

def get_yaw(q):
    return euler_from_quaternion([q.x, q.y, q.z, q.w])[2]

def stanley_control(x, y, yaw, v):
    global target_index

    if target_index >= len(path):
        return 0.0  # Stop steering when path is complete

    target = path[target_index]
    dx = target[0] - x
    dy = target[1] - y
    distance = math.sqrt(dx**2 + dy**2)

    # Advance waypoint if close enough
    if distance < 0.5 and target_index < len(path) - 1:
        rospy.loginfo(f"[ADVANCE] Reached point {target_index}, moving to {target_index+1}")
        target_index += 1
        target = path[target_index]
        dx = target[0] - x
        dy = target[1] - y

    # Calculate heading error
    path_heading = math.atan2(dy, dx)
    theta_e = math.atan2(math.sin(path_heading - yaw), math.cos(path_heading - yaw))

    # Cross-track error calculation (softened)
    cross_track_error = np.cross([math.cos(yaw), math.sin(yaw)], [dx, dy])
    cross_track_error = cross_track_error / (softening_factor + abs(cross_track_error))



    # ➡️ Publish the cross-track error
    cte_msg = Float32()
    cte_msg.data = cross_track_error
    cte_pub.publish(cte_msg)
    rospy.loginfo(f"[CROSS-TRACK ERROR] {cross_track_error:.4f} meters")

    # Dynamic gain that decreases with speed
    v_safe = max(v, min_speed)
    k_dynamic = k / (1.0 + 0.1 * v_safe)

    # Stanley steering formula
    delta = theta_e + math.atan2(k_dynamic * cross_track_error, v_safe)

    # Apply low-pass filter for smoother transitions
    if not hasattr(stanley_control, 'prev_steering'):
        stanley_control.prev_steering = delta
    delta = 0.3 * delta + 0.7 * stanley_control.prev_steering
    stanley_control.prev_steering = delta

    # Clip to maximum steering angle
    max_steering_rad = math.radians(max_steering_deg)
    delta = np.clip(delta, -max_steering_rad, max_steering_rad)

    rospy.loginfo(
        f"[STEERING] Angle: {math.degrees(delta):.1f}° | "
        f"Speed: {v:.2f}m/s | "
        f"Dynamic Gain: {k_dynamic:.2f}"
    )
    return delta

def model_states_callback(msg):
    global latest_msg
    latest_msg = msg

def control_callback(event):
    global latest_msg

    if not latest_msg:
        return

    try:
        index = latest_msg.name.index("ackermann_vehicle")
        pose = latest_msg.pose[index]
        twist = latest_msg.twist[index]

        x = pose.position.x
        y = pose.position.y
        yaw = get_yaw(pose.orientation)
        v = math.sqrt(twist.linear.x**2 + twist.linear.y**2)

        delta = stanley_control(x, y, yaw, v)

        msg = AckermannDrive()
        msg.steering_angle = delta
        ackermann_pub.publish(msg)

    except ValueError:
        rospy.logwarn("ackermann_vehicle not found in model_states!")

if __name__ == '__main__':
    rospy.init_node('stanley_path_follower')

    ackermann_pub = rospy.Publisher("/desired_steering", AckermannDrive, queue_size=10)
    cte_pub = rospy.Publisher("/cross_track_error", Float32, queue_size=10)  # Cross-Track Error publisher

    rospy.Subscriber('/gazebo/model_states', ModelStates, model_states_callback)

    rospy.Timer(rospy.Duration(0.1), control_callback)
    rospy.spin()

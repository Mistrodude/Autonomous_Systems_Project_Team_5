#!/usr/bin/env python3

import rospy
import sys
import termios
import tty
import select
from geometry_msgs.msg import Twist

# Key mappings for arrow keys
key_mapping = {
    '\x1b[A': (1.0, 0.0),   # Up Arrow → Forward
    '\x1b[B': (-1.0, 0.0),  # Down Arrow → Backward
    '\x1b[C': (0.5, -1.0),  # Right Arrow → Turn Right
    '\x1b[D': (0.5, 1.0),   # Left Arrow → Turn Left
    ' ': (0.0, 0.0)         # Spacebar → Stop
}

def get_key():
    """ Reads a single keypress from the terminal. """
    tty.setraw(sys.stdin.fileno())
    select.select([sys.stdin], [], [], 0)
    key = sys.stdin.read(3)  # Read 3 characters for arrow keys
    termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
    return key

def teleop():
    rospy.init_node("Autonomous_Systems_MS_2_Teleop_Team_05")
    pub = rospy.Publisher("/cmd_vel", Twist, queue_size=1)

    rospy.loginfo("Teleoperation Node Started. Use Arrow Keys to control. Press SPACE to stop.")

    rate = rospy.Rate(10)  # 10 Hz
    while not rospy.is_shutdown():
        key = get_key()
        if key in key_mapping:
            linear, angular = key_mapping[key]

            twist_msg = Twist()
            twist_msg.linear.x = linear  # Forward/backward speed
            twist_msg.angular.z = angular  # Steering

            pub.publish(twist_msg)
            rospy.loginfo(f"Published: Speed={linear}, Steering={angular}")

        elif key == '\x03':  # Ctrl+C to exit
            break

        rate.sleep()

if __name__ == "__main__":
    settings = termios.tcgetattr(sys.stdin)
    try:
        teleop()
    except rospy.ROSInterruptException:
        pass
    finally:
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)

